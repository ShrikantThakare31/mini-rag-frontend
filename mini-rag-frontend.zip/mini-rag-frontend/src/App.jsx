import { useState } from 'react'
import axios from 'axios'

export default function App(){
  const [query, setQuery] = useState('')
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)

  async function ask(){
    setLoading(true); setResults(null)
    try{
      const res = await axios.post('http://localhost:8000/rag_answer', { query }, { timeout: 5000 })
      setResults(res.data)
    }catch(e){
      // Mock retrieval
      const docs = [
        { id: 1, title: 'Configure Automations', snippet: 'Go to Settings → Automations → Create rule...' },
        { id: 2, title: 'CSAT Troubleshooting', snippet: 'If CSAT is not visible, check survey toggles and API keys.'}
      ]
      const answer = query.toLowerCase().includes('configure') ? 'To configure automations, go to Settings → Automations...' : 'CSAT may be missing due to survey config or outage.'
      setResults({ retrieved: docs, answer, confidence: 0.68 })
    }finally{ setLoading(false) }
  }

  return (
    <div className="container">
      <h1>Mini RAG — KB Answering</h1>
      <p className="small">Enter a query and get retrieved articles + generated answer.</p>

      <input className="input" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Ask: How do I configure automations in Hiver?" />
      <div style={{display:'flex', gap:8}}>
        <button className="btn" onClick={ask} disabled={loading}>{loading ? 'Thinking...' : 'Ask'}</button>
        <button className="btn" onClick={()=>{ setQuery(''); setResults(null)}} style={{background:'#6b7280'}}>Clear</button>
      </div>

      {results && (
        <>
          <div className="card">
            <h3>Retrieved Documents</h3>
            {results.retrieved?.map(d=>(
              <div key={d.id} style={{marginBottom:8}}>
                <strong>{d.title}</strong>
                <p className="small">{d.snippet}</p>
              </div>
            ))}
          </div>

          <div className="card">
            <h3>Generated Answer</h3>
            <p>{results.answer}</p>
            <p className="small"><strong>Confidence:</strong> {(results.confidence*100 || 70).toFixed(0)}%</p>
          </div>
        </>
      )}

      <div className="card">
        <h3>How to improve retrieval (notes)</h3>
        <ol>
          <li>Use embeddings (OpenAI / sentence-transformers) & chunking.</li>
          <li>Customer isolation: filter docs by customer namespace.</li>
          <li>Use hybrid TF-IDF + embeddings for precision.</li>
          <li>Store metadata (updated_at, author) to boost fresher docs.</li>
          <li>Cache frequent queries with hashed keys.</li>
        </ol>
      </div>
    </div>
  )
}
