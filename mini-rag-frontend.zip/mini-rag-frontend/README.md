# Mini RAG Frontend

Run:
1. cd mini-rag-frontend
2. npm install
3. npm run dev

This frontend expects a backend at http://localhost:8000/rag_answer.
If not present, it will use a local mocked response.
